from statistics import mode
from rest_framework import serializers
from .models import Article, Theme



class ThemeSerializers(serializers.ModelSerializer):
    class Meta:
        models = Theme
        fields = '__all__'



class ArticleSerializers(serializers.ModelSerializer):
    theme = ThemeSerializers
    class Meta:
        model = Article
        field = '__all_'
        