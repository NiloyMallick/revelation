from statistics import mode
from django.db import models

# Create your models here.

class Theme(models.Model):
    name = models.CharField(max_length=256)
    created_at = models.DateTimeField(auto_now=False, auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True, auto_now_add=False)


class Article(models.Model):
    title = models.CharField(max_length=256)
    preamble = models.CharField(max_length=256)
    surah_name = models.CharField(max_length=256)
    ayat = models.CharField(max_length=256)
    details = models.JSONField()
    theme = models.ManyToManyField(Theme, related_name='theme')
    created_at = models.DateTimeField(auto_now=False, auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True, auto_now_add=False)