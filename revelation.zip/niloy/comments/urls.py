from django.urls import path

from .views import CommentAPIView


urlpatterns = [
    path('create/', CommentAPIView.as_view(), name= "comment-create")


]