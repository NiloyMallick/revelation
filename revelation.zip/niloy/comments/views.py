from django.shortcuts import render
from rest_framework.generics import CreateAPIView, RetrieveUpdateDestroyAPIView, ListAPIView
# Create your views here.
from .models import Comment
from .serializers import CommentSerializers


class CommentAPIView(ListAPIView):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializers(queryset, many = True)
    # lookup_field = 'pk'