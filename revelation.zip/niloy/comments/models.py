from django.db import models
from django.contrib.auth.models import User
from articles.models import Article

# Create your models here.

class Comment(models.Model):
    details = models.TextField()
    user = models.ForeignKey(User , on_delete= models.CASCADE , related_name= 'user_comments' )
    article = models.ForeignKey(Article, on_delete=models.CASCADE, related_name= 'article_comments')
    created_at = models.DateTimeField(auto_now=False, auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True, auto_now_add=False)
